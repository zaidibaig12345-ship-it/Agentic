import json
import os
from datetime import datetime


def save_json(data: dict, filename: str, output_dir: str = "outputs/reports") -> str:
    """Save structured data as a JSON report file."""
    os.makedirs(output_dir, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    path = os.path.join(output_dir, f"{filename}_{timestamp}.json")
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
    print(f"Saved: {path}")
    return path


def save_report(text: str, filename: str, output_dir: str = "outputs/reports") -> str:
    """Save a text report file."""
    os.makedirs(output_dir, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    path = os.path.join(output_dir, f"{filename}_{timestamp}.txt")
    with open(path, 'w', encoding='utf-8') as f:
        f.write(text)
    print(f"Saved: {path}")
    return path


def load_corpus(file_path: str) -> str:
    """Load a text corpus from various file formats."""
    ext = os.path.splitext(file_path)[1].lower()
    if ext in ['.txt', '.csv']:
        with open(file_path, 'r', encoding='utf-8') as f:
            return f.read()
    elif ext == '.json':
        with open(file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
            if isinstance(data, list):
                return ' '.join(str(item) for item in data)
            return json.dumps(data)
    else:
        raise ValueError(f"Unsupported file format: {ext}. Use .txt, .csv, or .json")
