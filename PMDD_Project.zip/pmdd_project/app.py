import gradio as gr
from openai import OpenAI
import json
import os

from agents.agent1_preprocessor import run_agent1
from agents.agent2_pragmatic import run_agent2
from agents.agent3_semantic import run_agent3
from agents.agent4_statistics import run_agent4
from agents.agent5_orchestrator import run_orchestrator
from utils.helpers import save_json, save_report

# ─── CONFIGURATION ────────────────────────────────────────────────
# Set your OpenAI API key here or as an environment variable:
# export OPENAI_API_KEY="sk-..."
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "YOUR_OPENAI_API_KEY")
# ──────────────────────────────────────────────────────────────────


def analyze_corpus(file_obj, target_keywords: str):
    """Main pipeline: runs all 5 agents sequentially."""
    if file_obj is None:
        return "Please upload a corpus file.", "No file provided."

    client = OpenAI(api_key=OPENAI_API_KEY)
    keywords = [k.strip() for k in target_keywords.split(',') if k.strip()]
    log = []

    try:
        log.append("▶ Running Agent 1: Corpus Preprocessing...")
        a1 = run_agent1(file_obj.name)
        log.append(f"✔ Agent 1 complete. Segments: {a1['corpus_stats']['total_sentences']} | "
                   f"Words: {a1['corpus_stats']['total_words']}")

        log.append("▶ Running Agent 2: Pragmatic Analysis...")
        a2 = run_agent2(a1['segments'][:30], client)  # limit to 30 for speed
        labeled = sum(1 for s in a2 if s.get('speech_act'))
        log.append(f"✔ Agent 2 complete. {labeled}/{len(a2)} segments labeled.")

        log.append("▶ Running Agent 3: Semantic Field & Register Detection...")
        a3 = run_agent3(a1['segments'], keywords, client)
        log.append("✔ Agent 3 complete. Semantic drift map generated.")

        log.append("▶ Running Agent 4: Corpus Statistics...")
        a4 = run_agent4(a1['segments'], keywords)
        log.append(f"✔ Agent 4 complete. TTR: {a4['type_token_ratio']}")

        log.append("▶ Running Agent 5: Orchestrator — synthesizing report...")
        report = run_orchestrator(a1, a2, a3, a4, client)
        log.append("✔ Agent 5 complete. Linguistic report generated!")

        # Save outputs
        save_json({'agent1': a1, 'agent2': a2, 'agent3': a3, 'agent4': a4}, 'pmdd_data')
        save_report(report, 'pmdd_report')

    except Exception as e:
        log.append(f"✖ Error: {str(e)}")
        return '\n'.join(log), f"Pipeline failed: {str(e)}"

    return '\n'.join(log), report


# ─── GRADIO INTERFACE ─────────────────────────────────────────────
demo = gr.Interface(
    fn=analyze_corpus,
    inputs=[
        gr.File(label="Upload Corpus (.txt or .csv)"),
        gr.Textbox(
            label="Target Keywords (comma-separated)",
            value="community, power, change",
            placeholder="e.g. community, power, change, democracy"
        )
    ],
    outputs=[
        gr.Textbox(label="Agent Progress Log", lines=10),
        gr.Textbox(label="Linguistic Report", lines=30)
    ],
    title="PMDD — Pragmatic Meaning Drift Detector",
    description=(
        "Upload a text corpus (.txt or .csv) and receive a full linguistic analysis report.\n"
        "The system runs 5 AI agents grounded in Speech Act Theory, Gricean Maxims, "
        "Semantic Field Theory, Register Analysis, and Corpus Linguistics."
    ),
    examples=[],
    allow_flagging="never"
)

if __name__ == "__main__":
    demo.launch()
