# PMDD — Pragmatic Meaning Drift Detector
### Computational Linguistics | Agentic AI Project

---

## Setup

1. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   python -m spacy download en_core_web_sm
   ```

2. **Set your OpenAI API key**
   ```bash
   export OPENAI_API_KEY="sk-your-key-here"
   ```
   Or edit `app.py` and replace `"YOUR_OPENAI_API_KEY"` directly.

3. **Run the app**
   ```bash
   python app.py
   ```
   Then open the Gradio link shown in the terminal.

---

## Project Structure

```
pmdd_project/
├── app.py                        # Main Gradio app entry point
├── requirements.txt
├── README.md
├── agents/
│   ├── agent1_preprocessor.py    # Corpus cleaning & segmentation
│   ├── agent2_pragmatic.py       # Speech acts & Gricean analysis
│   ├── agent3_semantic.py        # Semantic fields & register detection
│   ├── agent4_statistics.py      # Frequency, collocation, keyness
│   └── agent5_orchestrator.py    # Report synthesis & feedback loop
├── utils/
│   └── helpers.py                # Shared utilities
└── outputs/
    └── reports/                  # Generated reports saved here
```

---

## The Five Agents

| Agent | Role | Theory |
|-------|------|--------|
| 01 | Corpus Preprocessor | Sinclair (1991) corpus methodology |
| 02 | Pragmatic Analyzer | Searle (1969), Grice (1975), Brown & Levinson (1987) |
| 03 | Semantic Field & Register Detector | Lyons (1977), Halliday (1978) |
| 04 | Corpus Statistician | Frequency, MI Score, Keyness, TTR |
| 05 | Orchestrator & Synthesizer | Fairclough (1992) CDA |

---

## Core Principle

> **Linguistics First, Technology Second.**
> The agents are tools. The linguistic evidence they produce must be interpretable,
> defensible, and grounded in the theoretical frameworks above.
