from collections import Counter
import math
import pandas as pd


def compute_frequency(segments: list) -> dict:
    """Compute word frequency lists per corpus section."""
    all_words = []
    for seg in segments:
        words = seg['text'].lower().split()
        all_words.extend(words)
    return dict(Counter(all_words).most_common(50))


def compute_collocates(segments: list, keyword: str, window: int = 5) -> list:
    """Find collocates within ±window words of a keyword."""
    collocates = []
    for seg in segments:
        words = seg['text'].lower().split()
        for i, word in enumerate(words):
            if word == keyword.lower():
                start = max(0, i - window)
                end = min(len(words), i + window + 1)
                context = words[start:i] + words[i+1:end]
                collocates.extend(context)
    return dict(Counter(collocates).most_common(20))


def compute_mi_score(freq_ab: int, freq_a: int, freq_b: int, total: int) -> float:
    """Calculate Mutual Information score for a collocation."""
    if freq_ab == 0 or freq_a == 0 or freq_b == 0:
        return 0.0
    return math.log2((freq_ab * total) / (freq_a * freq_b))


def compute_ttr(segments: list) -> float:
    """Compute Type-Token Ratio."""
    all_words = []
    for seg in segments:
        all_words.extend(seg['text'].lower().split())
    if not all_words:
        return 0.0
    return round(len(set(all_words)) / len(all_words), 4)


def run_agent4(segments: list, keywords: list = None) -> dict:
    """
    Agent 4: Corpus Statistician
    Performs quantitative corpus linguistic analysis.
    Linguistic Approach: Frequency Analysis, Collocation (Sinclair 1991),
    Keyness (Scott 1997), MI Score, Type-Token Ratio
    """
    if keywords is None:
        keywords = []

    freq = compute_frequency(segments)
    ttr = compute_ttr(segments)

    collocations = {}
    for kw in keywords:
        collocations[kw] = compute_collocates(segments, kw)

    # Split corpus into two halves for keyness comparison
    mid = len(segments) // 2
    first_half = segments[:mid]
    second_half = segments[mid:]
    freq_first = compute_frequency(first_half)
    freq_second = compute_frequency(second_half)

    # Basic keyness: words with biggest frequency ratio shift
    keyness = {}
    all_words = set(list(freq_first.keys()) + list(freq_second.keys()))
    for word in list(all_words)[:100]:
        f1 = freq_first.get(word, 0) + 1
        f2 = freq_second.get(word, 0) + 1
        keyness[word] = round(f2 / f1, 2)
    top_keyness = dict(sorted(keyness.items(), key=lambda x: abs(x[1] - 1), reverse=True)[:20])

    return {
        'top_50_frequencies': freq,
        'type_token_ratio': ttr,
        'collocations': collocations,
        'keyness_top_20': top_keyness,
        'total_segments': len(segments)
    }
