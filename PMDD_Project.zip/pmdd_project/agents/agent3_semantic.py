from openai import OpenAI
import json

SEMANTIC_PROMPT = '''You are a computational linguist specializing in Semantic Field Theory (Lyons 1977)
and Register Analysis (Halliday 1978).

For the given text segments, perform:
1. Semantic Field Clustering: group key content words into semantic fields
   (e.g., CONFLICT, ECONOMY, TECHNOLOGY, EMOTION, POLITICS, NATURE, etc.)
2. Register Classification per segment: Formal / Semi-Formal / Informal / Technical / Colloquial
3. Register Borrowing: flag any formal terms in informal contexts or vice versa
4. Semantic Drift: note any words appearing in unexpected semantic fields

Return ONLY valid JSON with this structure:
{
  "semantic_fields": {"FIELD_NAME": ["word1", "word2"]},
  "segments": [{"id": int, "register": string, "register_borrowing": bool, "drift_flags": [string]}]
}'''


def run_agent3(segments: list, keywords: list, client: OpenAI) -> dict:
    """
    Agent 3: Semantic Field & Register Detector
    Maps vocabulary drift and identifies register shifts.
    Linguistic Approach: Semantic Field Theory (Lyons 1977),
    Register Analysis (Halliday 1978 — Tenor, Field, Mode), Lexical Semantics
    """
    # Sample segments to avoid token limits
    sample = segments[:50] if len(segments) > 50 else segments
    segment_texts = [{'id': s['id'], 'text': s['text']} for s in sample]

    prompt = f"""Analyze these corpus segments for semantic fields and register.
Target keywords to track: {', '.join(keywords)}

Segments:
{json.dumps(segment_texts, indent=2)}"""

    response = client.chat.completions.create(
        model='gpt-4o',
        messages=[
            {'role': 'system', 'content': SEMANTIC_PROMPT},
            {'role': 'user', 'content': prompt}
        ],
        temperature=0.2,
        max_tokens=2000
    )
    raw = response.choices[0].message.content.strip()
    raw = raw.replace('```json', '').replace('```', '').strip()
    return json.loads(raw)
