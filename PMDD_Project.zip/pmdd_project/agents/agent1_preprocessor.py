import spacy
import json
import re

nlp = spacy.load('en_core_web_sm')

def run_agent1(file_path: str) -> dict:
    """
    Agent 1: Corpus Preprocessor & Segmenter
    Prepares raw text for linguistic analysis.
    Linguistic Approach: Corpus Linguistics Pre-processing (Sinclair's methodology)
    """
    with open(file_path, 'r', encoding='utf-8') as f:
        raw_text = f.read()

    # Remove noise: normalize whitespace, strip HTML tags
    text = re.sub(r'<[^>]+>', '', raw_text)
    text = re.sub(r'\s+', ' ', text).strip()

    doc = nlp(text)
    segments = []

    total_sents = list(doc.sents)
    for i, sent in enumerate(total_sents):
        segments.append({
            'id': i,
            'text': sent.text.strip(),
            'word_count': len([t for t in sent if not t.is_space]),
            'position': round(i / len(total_sents), 2)
        })

    return {
        'corpus_stats': {
            'total_sentences': len(segments),
            'total_words': sum(s['word_count'] for s in segments)
        },
        'segments': segments
    }
