from openai import OpenAI
import json


def run_orchestrator(a1_out: dict, a2_out: list, a3_out: dict, a4_out: dict, client: OpenAI) -> str:
    """
    Agent 5: Orchestrator & Evidence Synthesizer
    Synthesizes all evidence into a structured linguistic report.
    Linguistic Approach: Critical Discourse Analysis (Fairclough 1992),
    Evidence-Based Linguistic Reporting
    """
    # Quality check: if < 50% of segments have speech act labels, re-run Agent 2
    labeled = sum(1 for s in a2_out if s.get('speech_act'))
    if len(a2_out) > 0 and labeled / len(a2_out) < 0.5:
        print("Agent 2 coverage low — requesting re-analysis...")
        from agents.agent2_pragmatic import run_agent2
        a2_out = run_agent2(a1_out['segments'], client)

    synthesis_prompt = f"""You are a senior computational linguist. Synthesize these findings into a
formal linguistic evidence report:

- Corpus stats: {json.dumps(a1_out['corpus_stats'])}
- Pragmatic sample (first 5 segments): {json.dumps(a2_out[:5], indent=2)}
- Semantic drift analysis: {json.dumps(a3_out, indent=2)}
- Corpus statistics: {json.dumps(a4_out, indent=2)}

Write a formal linguistic evidence report with these exact sections:
1. Executive Summary (2 paragraphs)
2. Pragmatic Drift Evidence (cite segment IDs where possible)
3. Semantic Field Shifts (cite specific vocabulary)
4. Register Analysis Findings
5. Corpus Statistics Summary
6. Overall Meaning Drift Score (0-100) with sub-scores for:
   - Pragmatic Drift: X/100
   - Semantic Drift: X/100
   - Register Drift: X/100
   - Overall: X/100
   Include a brief justification for each score.

Be specific, cite evidence, and apply the relevant theoretical frameworks
(Grice, Searle, Halliday, Sinclair, Fairclough)."""

    response = client.chat.completions.create(
        model='gpt-4o',
        messages=[{'role': 'user', 'content': synthesis_prompt}],
        max_tokens=2000
    )
    return response.choices[0].message.content
