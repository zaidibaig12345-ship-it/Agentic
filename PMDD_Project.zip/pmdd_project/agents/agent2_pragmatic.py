from openai import OpenAI
import json

SYSTEM_PROMPT = '''You are a computational linguistics expert.
Analyze the given text segment using these exact frameworks:
1. Speech Act Theory (Searle): classify as one of:
   Assertive / Directive / Commissive / Expressive / Declaration
2. Gricean Maxims: list any violations:
   Quantity (too much/too little info) / Quality (unverifiable claim) /
   Relation (irrelevant) / Manner (unclear/ambiguous)
3. Implicature: identify as conventional or conversational
4. Politeness: score 1-5 (1=very face-threatening, 5=highly polite)
Return ONLY valid JSON with keys:
{speech_act, maxim_violations[], implicature, politeness_score}'''


def analyze_segment(segment_text: str, client: OpenAI) -> dict:
    response = client.chat.completions.create(
        model='gpt-4o',
        messages=[
            {'role': 'system', 'content': SYSTEM_PROMPT},
            {'role': 'user', 'content': f'Analyze: {segment_text}'}
        ],
        temperature=0.2
    )
    raw = response.choices[0].message.content.strip()
    raw = raw.replace('```json', '').replace('```', '').strip()
    return json.loads(raw)


def run_agent2(segments: list, client: OpenAI) -> list:
    """
    Agent 2: Pragmatic Analyzer
    Extracts speech acts, implicatures, and politeness patterns.
    Linguistic Approach: Speech Act Theory (Austin 1962, Searle 1969),
    Gricean Maxims (1975), Politeness Theory (Brown & Levinson 1987)
    """
    results = []
    for seg in segments:
        try:
            analysis = analyze_segment(seg['text'], client)
            results.append({**seg, **analysis})
        except Exception as e:
            results.append({**seg, 'speech_act': None, 'maxim_violations': [],
                            'implicature': None, 'politeness_score': None, 'error': str(e)})
    return results
